package bianuccijuancruzrecuperatorioprimerparcial121;

public class PlantaRepetidaException extends RuntimeException
{
    public final static String MESSAGE = "La planta ya se encuentra en el jardin"; 
    
    public PlantaRepetidaException()
    {
        super (MESSAGE);
    }
    
    
}
