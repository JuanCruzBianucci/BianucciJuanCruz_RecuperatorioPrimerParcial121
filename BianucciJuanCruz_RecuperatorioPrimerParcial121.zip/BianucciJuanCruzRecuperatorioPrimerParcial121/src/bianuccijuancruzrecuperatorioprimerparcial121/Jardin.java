package bianuccijuancruzrecuperatorioprimerparcial121;

import java.util.List;
import java.util.ArrayList;

public class Jardin 
{
    private String nombre;
    private ArrayList<Planta> plantas;

    public Jardin(String nombre) 
    {
        this.nombre = nombre;
        plantas = new ArrayList<>();
    }
    
    public void agregarPlanta(Planta planta)
    {
        if (plantas.contains(planta))
        {
            throw new PlantaRepetidaException();
        }
        
        plantas.add(planta);
    }
    
    public void mostrarPlantas ()
    {
        for (Planta p : plantas)
        {
            System.out.println(p);
        }
    }
    
        public void podarPlantas()
    {
        for (Planta p : plantas)
        {
            String nombreP = p.getNombre();
          
            if (p instanceof Podable po)
            {
                po.podar(nombreP);
            }
                           
            else 
            {
                System.out.println("El/La " + nombreP + " No requiere podarse.");
            }
        }
        
    }
    
}
