package bianuccijuancruzrecuperatorioprimerparcial121;

public interface Podable 
{
    default void podar(String nombre)
    {
        System.out.println("El/La " + nombre + " fue podado");
    }
    
}
