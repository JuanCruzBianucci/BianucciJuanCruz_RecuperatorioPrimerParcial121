package bianuccijuancruzrecuperatorioprimerparcial121;


public class Arbol extends Planta implements Podable
{
    private double alturaMaxima;

    public Arbol(double alturaMaxima, String nombre, String ubicacion, String clima) 
    {
        super(nombre, ubicacion, clima);
        this.alturaMaxima = alturaMaxima;
    }

    @Override
    public String toString() 
    {
        return super.toString() + ", alturaMaxima=" + alturaMaxima + '}';
    }
    
    
    
    
    
    
}
