
package bianuccijuancruzrecuperatorioprimerparcial121;

public enum Temporada 
{
    PRIMAVERA,
    VERANO,
    OTONIO,
    INVIERNO
}
