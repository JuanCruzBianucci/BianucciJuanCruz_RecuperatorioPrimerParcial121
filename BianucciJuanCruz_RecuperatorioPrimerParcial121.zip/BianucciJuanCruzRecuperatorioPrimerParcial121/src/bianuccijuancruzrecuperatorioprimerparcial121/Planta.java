package bianuccijuancruzrecuperatorioprimerparcial121;

import java.util.Objects;


public abstract class Planta 
{
    private String nombre;
    private String ubicacion;
    private String clima;

    public Planta(String nombre, String ubicacion, String clima) 
    {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.clima = clima;
    }

    @Override
    public String toString() {
        return "Nombre= " + nombre + ", Ubicacion= " + ubicacion + ", Clima= " + clima;
    }

    public String getNombre() 
    {
        return nombre;
    }
    
    
    @Override
    public boolean equals (Object p)
    {
        if (this == p)
        {
            return true;    
        }
        if (p == null)
        {
            return false;
        }
        
        if (p instanceof Planta ap)
        {
            return (ap.nombre.equals(nombre) && ap.ubicacion == ubicacion);
        }
        
        return false;
    }   
    
    @Override 
    public int hashCode()
    {
        return Objects.hash(nombre, ubicacion);
    }
    
    
}
