package bianuccijuancruzrecuperatorioprimerparcial121;

public class Arbusto extends Planta implements Podable
{
    private int densidadFollaje;

    public Arbusto(int densidadFollaje, String nombre, String ubicacion, String clima) 
    {    
        super(nombre, ubicacion, clima);
       
        if (densidadFollaje < 1 || densidadFollaje > 10) 
        {
            throw new IllegalArgumentException("Follaje fuera de rango!");
        }
        
        this.densidadFollaje = densidadFollaje;
    }
    
    @Override
    public String toString() 
    {
        return super.toString() + ", densidadFollaje=" + densidadFollaje + '}';
    }
    
    
    
    
}
