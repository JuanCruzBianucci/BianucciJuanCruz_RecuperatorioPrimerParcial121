package bianuccijuancruzrecuperatorioprimerparcial121;

public class Flor extends Planta
{
    private Temporada temporadaFlorecimiento;

    public Flor(Temporada temporadaFlorecimiento, String nombre, String ubicacion, String clima) 
    {
        super(nombre, ubicacion, clima);
        this.temporadaFlorecimiento = temporadaFlorecimiento;
    }

    @Override
    public String toString() 
    {
        return super.toString() + ", temporadaFlorecimiento=" + temporadaFlorecimiento + '}';
    }
    
    
    
    
    
}
