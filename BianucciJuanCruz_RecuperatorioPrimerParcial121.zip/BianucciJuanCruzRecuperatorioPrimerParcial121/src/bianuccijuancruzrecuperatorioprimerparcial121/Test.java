package bianuccijuancruzrecuperatorioprimerparcial121;

public class Test 
{

    public static void main(String[] args) 
    {
        Jardin j1 = new Jardin("Jardin Botanico");
          try
        {

            Planta p1 = new Arbol(10, "Fresno", "Zona Sur", "frio");
            Planta p2 = new Arbol(20, "Sauce Lloron", "Zona Este", "calido");
            Planta p3 = new Arbusto(5, "Libustrina", "Zona Remodelada", "templado");
            Planta p4 = new Arbusto(7, "Helecho", "Zona Norte", "calido");
            Planta p5 = new Flor(Temporada.PRIMAVERA, "Sarracenea", "Zona Sur", "muy Humedo");
            Planta p6 = new Flor(Temporada.VERANO, "Rosal", "Zona Remodelada", "muy Calido");

            //repetidos
            Planta p7 = new Arbol(20, "Sauce Lloron", "Zona Este", "calido");
            Planta p8 = new Flor(Temporada.INVIERNO, "Sauce Lloron", "Zona Este", "templado");
        
      
            j1.agregarPlanta(p1);
            j1.agregarPlanta(p2);
            j1.agregarPlanta(p3);
            j1.agregarPlanta(p4);
            j1.agregarPlanta(p5);
            j1.agregarPlanta(p6);
            
            j1.agregarPlanta(p7);
        }
        catch (PlantaRepetidaException ex)
        {
            System.out.println(ex.getMessage());
        }
          
        catch (IllegalArgumentException ex)
        {
                System.out.println(ex.getMessage());
        }
          
        finally
        {
            System.out.println("Fin de las cargas");
        }

        System.out.println("-----------------------------------");

        
        j1.mostrarPlantas();
        
        System.out.println("-----------------------------------");
        
        j1.podarPlantas();
        
        System.out.println("-----------------------------------");

        
        
        
        
    }
    
}
